#vector representation
a=c(1,2,3,4,5,6)
print(a)

#addition
b=a+5
print(b)

#subtraction
c=a-5
print(c)

#exponent
f=a^5
print(f)
#square root
g=sqrt(a)
print(g)

x=-1:10
print(x)
y=-5:6
print(y)
k=x+y
print(k)
l=x-y
print(l)
m=x*y
print(m)