A<-matrix(1:10,nrow=5)
A
B<-matrix(1:10,nrow=5,byrow = T)
B
dim(A)
A+B
nrow(A)
ncol(B)
